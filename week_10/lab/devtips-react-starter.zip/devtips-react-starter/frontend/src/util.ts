export type TTip = {
  id: string;
  text: string;
  likes: number;
};

export const BASE_URL = `http://localhost:5000`;
